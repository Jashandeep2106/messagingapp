# gui.py - Graphical User Interface (Tkinter)

import tkinter as tk
from tkinter import scrolledtext, messagebox, filedialog, ttk
import threading
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from client.client import MessagingClient


class LoginWindow:
    """
    The first window the user sees.
    Allows login or switching to registration.
    """

    def __init__(self, root):
        self.root = root
        self.root.title("Messaging App - Login")
        self.root.geometry("400x300")
        self.root.resizable(False, False)
        self.root.configure(bg="#1e1e2e")

        self.client = MessagingClient()
        self.client.connect()

        # Set callbacks
        self.client.on_login_response = self.handle_login_response
        self.client.on_register_response = self.handle_register_response

        self.build_login_ui()

    def build_login_ui(self):
        """Builds the login form UI."""

        # Clear window
        for widget in self.root.winfo_children():
            widget.destroy()

        tk.Label(self.root, text="💬 Messaging App",
                 font=("Helvetica", 18, "bold"),
                 bg="#1e1e2e", fg="#cdd6f4").pack(pady=20)

        tk.Label(self.root, text="Username",
                 bg="#1e1e2e", fg="#cdd6f4").pack()
        self.username_entry = tk.Entry(self.root, width=30,
                                       bg="#313244", fg="#cdd6f4",
                                       insertbackground="white")
        self.username_entry.pack(pady=5)

        tk.Label(self.root, text="Password",
                 bg="#1e1e2e", fg="#cdd6f4").pack()
        self.password_entry = tk.Entry(self.root, width=30, show="*",
                                       bg="#313244", fg="#cdd6f4",
                                       insertbackground="white")
        self.password_entry.pack(pady=5)

        tk.Button(self.root, text="Login",
                  command=self.login,
                  bg="#89b4fa", fg="#1e1e2e",
                  width=20).pack(pady=10)

        tk.Button(self.root, text="Register Instead",
                  command=self.build_register_ui,
                  bg="#313244", fg="#cdd6f4",
                  width=20).pack()

    def build_register_ui(self):
        """Builds the registration form UI."""

        for widget in self.root.winfo_children():
            widget.destroy()

        tk.Label(self.root, text="📝 Register",
                 font=("Helvetica", 18, "bold"),
                 bg="#1e1e2e", fg="#cdd6f4").pack(pady=20)

        tk.Label(self.root, text="Username",
                 bg="#1e1e2e", fg="#cdd6f4").pack()
        self.reg_username = tk.Entry(self.root, width=30,
                                     bg="#313244", fg="#cdd6f4",
                                     insertbackground="white")
        self.reg_username.pack(pady=5)

        tk.Label(self.root, text="Password",
                 bg="#1e1e2e", fg="#cdd6f4").pack()
        self.reg_password = tk.Entry(self.root, width=30, show="*",
                                     bg="#313244", fg="#cdd6f4",
                                     insertbackground="white")
        self.reg_password.pack(pady=5)

        tk.Button(self.root, text="Register",
                  command=self.register,
                  bg="#a6e3a1", fg="#1e1e2e",
                  width=20).pack(pady=10)

        tk.Button(self.root, text="Back to Login",
                  command=self.build_login_ui,
                  bg="#313244", fg="#cdd6f4",
                  width=20).pack()

    def login(self):
        """Sends login request to server."""
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        if not username or not password:
            messagebox.showwarning("Warning", "Please fill in all fields.")
            return
        self.client.login(username, password)

    def register(self):
        """Sends registration request to server."""
        username = self.reg_username.get().strip()
        password = self.reg_password.get().strip()
        if not username or not password:
            messagebox.showwarning("Warning", "Please fill in all fields.")
            return
        self.client.register(username, password)

    def handle_login_response(self, data):
        """Callback: handles login response from server."""
        if data["success"]:
            # Open main chat window
            self.root.after(0, lambda: self.open_chat(data))
        else:
            self.root.after(0, lambda: messagebox.showerror("Login Failed", data["message"]))

    def handle_register_response(self, data):
        """Callback: handles registration response from server."""
        if data["success"]:
            self.root.after(0, lambda: [
                messagebox.showinfo("Success", data["message"]),
                self.build_login_ui()
            ])
        else:
            self.root.after(0, lambda: messagebox.showerror("Error", data["message"]))

    def open_chat(self, data):
        """Opens the main chat window after successful login."""
        self.root.destroy()
        chat_root = tk.Tk()
        ChatWindow(chat_root, self.client, data)
        chat_root.mainloop()


class ChatWindow:
    """
    Main chat interface shown after login.
    Displays online users, chat history, and message input.
    """

    def __init__(self, root, client, login_data):
        self.root = root
        self.client = client
        self.username = client.username
        self.selected_contact = None

        self.root.title(f"💬 Messaging App — {self.username}")
        self.root.geometry("800x550")
        self.root.configure(bg="#1e1e2e")

        # Set callbacks
        self.client.on_message_received = self.display_message
        self.client.on_file_received = self.display_file_notification
        self.client.on_user_list_updated = self.update_user_list

        self.build_chat_ui()

        # Load initial user list
        if "all_users" in login_data:
            self.update_user_list(login_data["all_users"])

        # Handle window close
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def build_chat_ui(self):
        """Builds the main chat window layout."""

        # Left Panel (Online Users) 
        left_frame = tk.Frame(self.root, bg="#181825", width=180)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=5, pady=5)
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="🟢 Online Users",
                 bg="#181825", fg="#a6e3a1",
                 font=("Helvetica", 11, "bold")).pack(pady=10)

        self.users_listbox = tk.Listbox(left_frame,
                                        bg="#313244", fg="#cdd6f4",
                                        selectbackground="#89b4fa",
                                        selectforeground="#1e1e2e",
                                        font=("Helvetica", 10),
                                        borderwidth=0)
        self.users_listbox.pack(fill=tk.BOTH, expand=True, padx=5)
        self.users_listbox.bind("<<ListboxSelect>>", self.on_user_select)

        # Right Panel (Chat Area) 
        right_frame = tk.Frame(self.root, bg="#1e1e2e")
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Selected contact header
        self.contact_label = tk.Label(right_frame,
                                       text="Select a user to chat",
                                       bg="#181825", fg="#89b4fa",
                                       font=("Helvetica", 12, "bold"),
                                       pady=8)
        self.contact_label.pack(fill=tk.X, pady=(0, 5))

        # Chat display area
        self.chat_display = scrolledtext.ScrolledText(
            right_frame,
            state=tk.DISABLED,
            bg="#181825", fg="#cdd6f4",
            font=("Helvetica", 10),
            wrap=tk.WORD,
            borderwidth=0
        )
        self.chat_display.pack(fill=tk.BOTH, expand=True)

        # Bottom Input Area 
        input_frame = tk.Frame(right_frame, bg="#1e1e2e")
        input_frame.pack(fill=tk.X, pady=(5, 0))

        self.message_entry = tk.Entry(input_frame,
                                       bg="#313244", fg="#cdd6f4",
                                       insertbackground="white",
                                       font=("Helvetica", 11))
        self.message_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        self.message_entry.bind("<Return>", lambda e: self.send_message())

        tk.Button(input_frame, text="Send",
                  command=self.send_message,
                  bg="#89b4fa", fg="#1e1e2e",
                  width=8).pack(side=tk.LEFT, padx=(0, 5))

        tk.Button(input_frame, text="📎 File",
                  command=self.send_file,
                  bg="#f38ba8", fg="#1e1e2e",
                  width=8).pack(side=tk.LEFT)

    def on_user_select(self, event):
        """Handles user selection from the online users list."""
        selection = self.users_listbox.curselection()
        if selection:
            selected = self.users_listbox.get(selection[0])
            if selected != self.username:
                self.selected_contact = selected
                self.contact_label.config(text=f"💬 Chat with: {selected}")
                self.chat_display.config(state=tk.NORMAL)
                self.chat_display.delete(1.0, tk.END)
                self.chat_display.config(state=tk.DISABLED)

    def send_message(self):
        """Sends a text message to the selected contact."""
        if not self.selected_contact:
            messagebox.showwarning("Warning", "Please select a user to chat with.")
            return
        message = self.message_entry.get().strip()
        if not message:
            return
        self.client.send_message(self.selected_contact, message)
        self.display_message(f"You", message, sent=True)
        self.message_entry.delete(0, tk.END)

    def send_file(self):
        """Opens file dialog and sends selected file."""
        if not self.selected_contact:
            messagebox.showwarning("Warning", "Please select a user first.")
            return
        filepath = filedialog.askopenfilename(title="Select a file to send")
        if filepath:
            threading.Thread(
                target=self.client.send_file,
                args=(self.selected_contact, filepath),
                daemon=True
            ).start()
            filename = os.path.basename(filepath)
            self.display_message("You", f"📎 Sent file: {filename}", sent=True)

    def display_message(self, sender, message, sent=False):
        """Displays a message in the chat window."""
        self.chat_display.config(state=tk.NORMAL)
        prefix = "➤ " if sent else "◀ "
        color_tag = "sent" if sent else "received"
        self.chat_display.insert(tk.END, f"{prefix}{sender}: {message}\n")
        self.chat_display.config(state=tk.DISABLED)
        self.chat_display.yview(tk.END)

    def display_file_notification(self, sender, filename, save_path):
        """Displays a notification when a file is received."""
        self.root.after(0, lambda: self.display_message(
            sender, f"📎 Sent you a file: {filename} (saved to {save_path})"
        ))

    def update_user_list(self, users):
        """Updates the online users listbox."""
        def _update():
            self.users_listbox.delete(0, tk.END)
            for user in users:
                if user != self.username:
                    self.users_listbox.insert(tk.END, user)
        self.root.after(0, _update)

    def on_close(self):
        """Handles window close event."""
        self.client.disconnect()
        self.root.destroy()


# Entry Point 
if __name__ == "__main__":
    root = tk.Tk()
    app = LoginWindow(root)
    root.mainloop()
# client.py - Client Networking Script

import socket
import threading
import json
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from client.file_transfer import send_file, receive_file

# Load config
with open("config/config.json", "r") as f:
    config = json.load(f)

HOST = config["host"]
PORT = config["port"]
BUFFER_SIZE = config["buffer_size"]


class MessagingClient:
    """
    Manages the TCP socket connection to the server.
    Sends and receives messages and files.
    Calls GUI callback functions when data arrives.
    """

    def __init__(self):
        self.socket = None
        self.username = None
        self.connected = False

        # Callback functions set by gui.py
        self.on_message_received = None      
        self.on_file_received = None        
        self.on_user_list_updated = None    
        self.on_login_response = None        
        self.on_register_response = None     

    def connect(self):
        """
        Establishes a TCP connection to the server.
        Starts a background thread to listen for incoming messages.
        """
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.connect((HOST, PORT))
            self.connected = True

            # Start listening thread
            listen_thread = threading.Thread(target=self.listen, daemon=True)
            listen_thread.start()
            print(f"[CONNECTED] Connected to server at {HOST}:{PORT}")
            return True
        except Exception as e:
            print(f"[ERROR] Could not connect to server: {e}")
            return False

    def listen(self):
        """
        Continuously listens for incoming data from the server.
        Runs in a background thread.
        Handles text messages, file transfers, and user list updates.
        """
        while self.connected:
            try:
                raw_data = self.socket.recv(BUFFER_SIZE)
                if not raw_data:
                    break

                data = json.loads(raw_data.decode("utf-8"))
                msg_type = data.get("type")

                # Incoming Text Message 
                if msg_type == "text_message":
                    if self.on_message_received:
                        self.on_message_received(data["sender"], data["message"])

                # Incoming File 
                elif msg_type == "file_incoming":
                    filename = data["filename"]
                    filesize = data["filesize"]
                    sender = data["sender"]
                    # Receive the actual file bytes
                    save_path = receive_file(self.socket, filename, filesize)
                    if self.on_file_received:
                        self.on_file_received(sender, filename, save_path)

                # Updated Online Users List 
                elif msg_type == "user_list":
                    if self.on_user_list_updated:
                        self.on_user_list_updated(data["users"])

                # Login Response 
                elif msg_type == "login_response":
                    if self.on_login_response:
                        self.on_login_response(data)

                # Register Response 
                elif msg_type == "register_response":
                    if self.on_register_response:
                        self.on_register_response(data)

            except Exception as e:
                print(f"[ERROR] Lost connection to server: {e}")
                self.connected = False
                break

    def register(self, username, password):
        """
        Sends a registration request to the server.
        """
        payload = json.dumps({
            "type": "register",
            "username": username,
            "password": password
        })
        self.socket.send(payload.encode("utf-8"))

    def login(self, username, password):
        """
        Sends a login request to the server.
        """
        self.username = username
        payload = json.dumps({
            "type": "login",
            "username": username,
            "password": password
        })
        self.socket.send(payload.encode("utf-8"))

    def send_message(self, receiver, message):
        """
        Sends a text message to another user via the server.
        """
        payload = json.dumps({
            "type": "text_message",
            "receiver": receiver,
            "message": message
        })
        self.socket.send(payload.encode("utf-8"))
        print(f"[SENT] {self.username} -> {receiver}: {message}")

    def send_file(self, receiver, filepath):
        """
        Sends a file to another user via the server.
        """
        send_file(self.socket, receiver, filepath, BUFFER_SIZE)

    def disconnect(self):
        """
        Gracefully disconnects from the server.
        """
        if self.connected:
            payload = json.dumps({"type": "disconnect"})
            self.socket.send(payload.encode("utf-8"))
            self.connected = False
            self.socket.close()
            print("[DISCONNECTED] Disconnected from server.")
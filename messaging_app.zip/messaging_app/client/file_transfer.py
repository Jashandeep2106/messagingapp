# file_transfer.py - File Transfer Handler (Client Side)

import os
import json


def send_file(client_socket, receiver, filepath, buffer_size=4096):
    """
    Sends a file to the server for forwarding to the receiver.
    First sends file metadata (name, size), then sends file in chunks.

    Args:
        client_socket: The connected socket object
        receiver: Username of the intended recipient
        filepath: Full path to the file being sent
        buffer_size: Size of each chunk in bytes
    """

    # Check if file exists
    if not os.path.exists(filepath):
        print(f"[ERROR] File not found: {filepath}")
        return False

    filename = os.path.basename(filepath)
    filesize = os.path.getsize(filepath)

    # Send file metadata as JSON first
    metadata = json.dumps({
        "type": "file_transfer",
        "receiver": receiver,
        "filename": filename,
        "filesize": filesize
    })
    client_socket.send(metadata.encode("utf-8"))

    # Small delay to ensure metadata is processed before file bytes
    import time
    time.sleep(0.1)

    # Send file content in chunks
    sent = 0
    with open(filepath, "rb") as f:
        while True:
            chunk = f.read(buffer_size)
            if not chunk:
                break
            client_socket.send(chunk)
            sent += len(chunk)

    print(f"[FILE SENT] {filename} ({sent} bytes) -> {receiver}")
    return True


def receive_file(client_socket, filename, filesize, save_folder="uploads/", buffer_size=4096):
    """
    Receives an incoming file from the server and saves it locally.

    Args:
        client_socket: The connected socket object
        filename: Name of the incoming file
        filesize: Expected size of the file in bytes
        save_folder: Local folder to save the received file
        buffer_size: Size of each chunk in bytes
    """

    # Create save folder if it doesn't exist
    os.makedirs(save_folder, exist_ok=True)
    save_path = os.path.join(save_folder, filename)

    # Receive file content in chunks
    received = 0
    with open(save_path, "wb") as f:
        while received < filesize:
            chunk = client_socket.recv(min(buffer_size, filesize - received))
            if not chunk:
                break
            f.write(chunk)
            received += len(chunk)

    print(f"[FILE RECEIVED] {filename} saved to {save_path}")
    return save_path



    
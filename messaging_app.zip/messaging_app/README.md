# B205 Messaging Application

A Python-based real-time messaging application built for the B205 Computer Networks module at Gisma University of Applied Sciences.

## Features

- Real-time text messaging between users
- File and photo transfer
- User registration and login (with hashed passwords)
- Online user list / contact management
- SQLite database for message and user storage
- Logging system

## Architecture

Client-Server Architecture using TCP Sockets

## How to Run

### Step 1 - Start the Server

```bash
cd messaging_app
python -m server.server
```

### Step 2 - Start the Client (open in a new terminal)

```bash
cd messaging_app
python -m client.gui
```

### Step 3 - Register and Login

- Click "Register Instead" to create an account
- Login with your credentials
- Select a user from the online list and start chatting

## Project Structure

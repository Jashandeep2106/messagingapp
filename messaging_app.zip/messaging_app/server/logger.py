# logger.py - Logging configuration for the messaging server

import logging
import os

def setup_logger(log_file="logs/server.log"):
    """
    Sets up the logger to write logs to both a file and the console.
    Creates the logs directory if it doesn't exist.
    """

    # Create logs directory if it doesn't exist
    os.makedirs(os.path.dirname(log_file), exist_ok=True)

    # Create a custom logger
    logger = logging.getLogger("MessagingApp")
    logger.setLevel(logging.DEBUG)  

    # File Handler (writes logs to file) 
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)

    # Console Handler (prints logs to terminal)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)

    # Log Format
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    # Add handlers to logger
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger


# Create a global logger instance to be imported by other modules
logger = setup_logger()
# database.py - SQLite Database Handler

import sqlite3
import hashlib
import os
import json
from server.logger import logger

# Load config
with open("config/config.json", "r") as f:
    config = json.load(f)

DB_FILE = config["db_file"]


def get_connection():
    """
    Creates and returns a new SQLite database connection.
    """
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row  
    return conn


def initialize_database():
    """
    Creates all required tables if they don't already exist.
    Called automatically when the server starts.
    """
    os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
    conn = get_connection()
    cursor = conn.cursor()

    # Users Table 
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Messages Table 
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender TEXT NOT NULL,
            receiver TEXT NOT NULL,
            message TEXT,
            message_type TEXT DEFAULT 'text',
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Contacts Table 
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            contact_username TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    conn.commit()
    conn.close()
    logger.info("Database initialized successfully.")


def hash_password(password):
    """
    Hashes a plain-text password using SHA-256 for secure storage.
    """
    return hashlib.sha256(password.encode()).hexdigest()


def register_user(username, password):
    """
    Registers a new user in the database.
    Returns True if successful, False if username already exists.
    """
    try:
        conn = get_connection()
        cursor = conn.cursor()
        hashed = hash_password(password)
        cursor.execute(
            "INSERT INTO users (username, password) VALUES (?, ?)",
            (username, hashed)
        )
        conn.commit()
        conn.close()
        logger.info(f"New user registered: {username}")
        return True
    except sqlite3.IntegrityError:
        logger.warning(f"Registration failed: Username '{username}' already exists.")
        return False


def authenticate_user(username, password):
    """
    Checks if the provided username and password match a record in the database.
    Returns True if authenticated, False otherwise.
    """
    conn = get_connection()
    cursor = conn.cursor()
    hashed = hash_password(password)
    cursor.execute(
        "SELECT * FROM users WHERE username = ? AND password = ?",
        (username, hashed)
    )
    user = cursor.fetchone()
    conn.close()
    if user:
        logger.info(f"User authenticated: {username}")
        return True
    logger.warning(f"Authentication failed for user: {username}")
    return False


def save_message(sender, receiver, message, message_type="text"):
    """
    Saves a message to the messages table in the database.
    """
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO messages (sender, receiver, message, message_type) VALUES (?, ?, ?, ?)",
        (sender, receiver, message, message_type)
    )
    conn.commit()
    conn.close()
    logger.debug(f"Message saved: {sender} -> {receiver} [{message_type}]")


def get_message_history(user1, user2):
    """
    Retrieves the chat history between two users.
    Returns a list of message rows.
    """
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT sender, receiver, message, message_type, timestamp
        FROM messages
        WHERE (sender = ? AND receiver = ?)
           OR (sender = ? AND receiver = ?)
        ORDER BY timestamp ASC
    """, (user1, user2, user2, user1))
    messages = cursor.fetchall()
    conn.close()
    return messages


def add_contact(username, contact_username):
    """
    Adds a contact for a user.
    """
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM users WHERE username = ?", (username,))
    user = cursor.fetchone()
    if user:
        cursor.execute(
            "INSERT INTO contacts (user_id, contact_username) VALUES (?, ?)",
            (user["id"], contact_username)
        )
        conn.commit()
        logger.info(f"Contact added: {username} -> {contact_username}")
    conn.close()


def get_contacts(username):
    """
    Returns the list of contacts for a given user.
    """
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM users WHERE username = ?", (username,))
    user = cursor.fetchone()
    contacts = []
    if user:
        cursor.execute(
            "SELECT contact_username FROM contacts WHERE user_id = ?",
            (user["id"],)
        )
        contacts = [row["contact_username"] for row in cursor.fetchall()]
    conn.close()
    return contacts


def get_all_users():
    """
    Returns a list of all registered usernames.
    """
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT username FROM users")
    users = [row["username"] for row in cursor.fetchall()]
    conn.close()
    return users

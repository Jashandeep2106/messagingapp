# server.py - Main Server Script

import socket
import threading
import json
import os
import sys

# Add root directory to path so imports work correctly
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from server.database import initialize_database, authenticate_user, register_user, save_message, get_all_users, get_contacts
from server.logger import logger

# Load Configuration 
with open("config/config.json", "r") as f:
    config = json.load(f)

HOST = config["host"]
PORT = config["port"]
BUFFER_SIZE = config["buffer_size"]
MAX_CONNECTIONS = config["max_connections"]
UPLOAD_FOLDER = config["upload_folder"]

# Global dictionary to track connected clients 
# Format: { "username": client_socket }
connected_clients = {}
clients_lock = threading.Lock()  


def broadcast_user_list():
    """
    Sends the updated list of online users to all connected clients.
    Called whenever a user connects or disconnects.
    """
    online_users = list(connected_clients.keys())
    message = json.dumps({
        "type": "user_list",
        "users": online_users
    })
    with clients_lock:
        for client_socket in connected_clients.values():
            try:
                client_socket.send(message.encode("utf-8"))
            except Exception as e:
                logger.error(f"Error broadcasting user list: {e}")


def handle_text_message(data, sender_username):
    """
    Routes a text message from sender to the intended receiver.
    Also saves the message to the database.
    """
    receiver = data.get("receiver")
    message = data.get("message")

    # Save message to database
    save_message(sender_username, receiver, message, "text")

    # Build the payload to send to receiver
    payload = json.dumps({
        "type": "text_message",
        "sender": sender_username,
        "message": message
    })

    # Send to receiver if they are online
    with clients_lock:
        if receiver in connected_clients:
            try:
                connected_clients[receiver].send(payload.encode("utf-8"))
                logger.info(f"Message routed: {sender_username} -> {receiver}")
            except Exception as e:
                logger.error(f"Failed to send message to {receiver}: {e}")
        else:
            logger.warning(f"Receiver '{receiver}' is not online.")


def handle_file_transfer(data, sender_username, client_socket):
    """
    Handles incoming file transfer from a client.
    Receives the file in chunks and saves it to the uploads folder.
    Then forwards the file to the intended receiver.
    """
    receiver = data.get("receiver")
    filename = data.get("filename")
    filesize = data.get("filesize")

    logger.info(f"File transfer started: {sender_username} -> {receiver} | File: {filename} | Size: {filesize} bytes")

    # Create uploads folder if it doesn't exist
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    save_path = os.path.join(UPLOAD_FOLDER, filename)

    # Receive file data in chunks
    received = 0
    with open(save_path, "wb") as f:
        while received < filesize:
            chunk = client_socket.recv(min(BUFFER_SIZE, filesize - received))
            if not chunk:
                break
            f.write(chunk)
            received += len(chunk)

    logger.info(f"File received and saved: {save_path}")

    # Save file message to database
    save_message(sender_username, receiver, filename, "file")

    # Notify the receiver about the incoming file
    with clients_lock:
        if receiver in connected_clients:
            try:
                # Send file metadata first
                notify = json.dumps({
                    "type": "file_incoming",
                    "sender": sender_username,
                    "filename": filename,
                    "filesize": filesize
                })
                connected_clients[receiver].send(notify.encode("utf-8"))

                # Send the actual file content
                with open(save_path, "rb") as f:
                    while True:
                        chunk = f.read(BUFFER_SIZE)
                        if not chunk:
                            break
                        connected_clients[receiver].send(chunk)

                logger.info(f"File forwarded to receiver: {receiver}")
            except Exception as e:
                logger.error(f"Failed to forward file to {receiver}: {e}")


def handle_client(client_socket, client_address):
    """
    Main handler for each connected client.
    Runs in its own thread.
    Handles login, registration, messaging, and file transfer.
    """
    logger.info(f"New connection from {client_address}")
    username = None

    try:
        while True:
            # Receive data from client
            raw_data = client_socket.recv(BUFFER_SIZE)
            if not raw_data:
                break

            # Decode the incoming JSON message
            try:
                data = json.loads(raw_data.decode("utf-8"))
            except json.JSONDecodeError:
                logger.error(f"Invalid JSON received from {client_address}")
                continue

            msg_type = data.get("type")

            # Handle Registration 
            if msg_type == "register":
                uname = data.get("username")
                pwd = data.get("password")
                success = register_user(uname, pwd)
                response = json.dumps({
                    "type": "register_response",
                    "success": success,
                    "message": "Registration successful!" if success else "Username already taken."
                })
                client_socket.send(response.encode("utf-8"))

            # Handle Login
            elif msg_type == "login":
                uname = data.get("username")
                pwd = data.get("password")
                success = authenticate_user(uname, pwd)
                if success:
                    username = uname
                    with clients_lock:
                        connected_clients[username] = client_socket
                    broadcast_user_list()
                    # Send contacts list to user
                    contacts = get_contacts(username)
                    all_users = get_all_users()
                    response = json.dumps({
                        "type": "login_response",
                        "success": True,
                        "message": "Login successful!",
                        "contacts": contacts,
                        "all_users": all_users
                    })
                else:
                    response = json.dumps({
                        "type": "login_response",
                        "success": False,
                        "message": "Invalid username or password."
                    })
                client_socket.send(response.encode("utf-8"))

            # Handle Text Message
            elif msg_type == "text_message":
                if username:
                    handle_text_message(data, username)

            # Handle File Transfer 
            elif msg_type == "file_transfer":
                if username:
                    handle_file_transfer(data, username, client_socket)

            # Handle Disconnect 
            elif msg_type == "disconnect":
                logger.info(f"Client {username} requested disconnect.")
                break

    except Exception as e:
        logger.error(f"Error handling client {client_address}: {e}")

    finally:
        # Clean up when client disconnects
        if username:
            with clients_lock:
                if username in connected_clients:
                    del connected_clients[username]
            broadcast_user_list()
            logger.info(f"Client disconnected: {username}")
        client_socket.close()


def start_server():
    """
    Starts the TCP server, listens for incoming connections,
    and spawns a new thread for each connected client.
    """
    # Initialize database tables on startup
    initialize_database()

    # Create uploads folder if not exists
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)

    # Create and configure the server socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((HOST, PORT))
    server_socket.listen(MAX_CONNECTIONS)

    logger.info(f"Server started on {HOST}:{PORT}")
    logger.info(f"Waiting for connections (max: {MAX_CONNECTIONS})...")

    try:
        while True:
            # Accept new client connection
            client_socket, client_address = server_socket.accept()
            logger.info(f"Connection accepted from {client_address}")

            # Start a new thread to handle this client
            client_thread = threading.Thread(
                target=handle_client,
                args=(client_socket, client_address),
                daemon=True
            )
            client_thread.start()

    except KeyboardInterrupt:
        logger.info("Server shutting down...")
    finally:
        server_socket.close()


# Entry Point 
if __name__ == "__main__":
    start_server()